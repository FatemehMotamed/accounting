# accounting
A Django-based system to manage the accounting of classes
